#include<fstream>
#include<iostream>
#include<sstream>
#include<vector>
#include "snap.h"
#include "cr.h"
#include "csg.h"
#include "cdh.h"
#include "Schedule.h"
#include "StudentClass.h"
using namespace std;


#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

int main(int argc, char* argv[]) 
{
	VS_MEM_CHECK

	//Opening files
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	// open argv[2] file or cout for output
	ostream& out = (argc > 2) ? *(new ofstream(argv[2])) : cout;
	if (!out) return 2;

	vector<Snap> snapVec;
	vector<cr> crVec;
	vector<csg> csgVec;
	vector<cdh> cdhVec;

	string courseName, room, studentId, studentName, studentAddress, studentPhone,
		   studentGrade, day, time;
	out << "Input Strings: " << endl;
	for (string line; getline(in, line);)	// Read until EOF 
	{
		try
		{
			if ("cr(" == line.substr(0, 3))
			{
				courseName = line.substr(3, line.find(',') - 3);
				line = line.substr(line.find(',') + 1);
				room = line.substr(0, line.find(')'));
				cr course = cr(courseName, room);
				out << course << "." << endl;
				crVec.push_back(course);
			}
			else if ("snap(" == line.substr(0, 5))
			{
				studentId = line.substr(5, line.find(',') - 5);
				line = line.substr(line.find(',') + 1);
				studentName = line.substr(0, line.find(','));
				line = line.substr(line.find(',') + 1);
				studentAddress = line.substr(0, line.find(','));
				line = line.substr(line.find(',') + 1);
				studentPhone = line.substr(0, line.find(')'));
				Snap student = Snap(studentName, studentId, studentAddress, studentPhone);
				out << "snap(" << student << ")" << "." << endl;
				snapVec.push_back(student);
			}
			else if ("csg(" == line.substr(0, 4))
			{
				courseName = line.substr(4, line.find(',') - 4);
				line = line.substr(line.find(',') + 1);
				studentId = line.substr(0, line.find(','));
				line = line.substr(line.find(',') + 1);
				studentGrade = line.substr(0, line.find(')'));
				csg grade = csg(courseName, studentId, studentGrade);
				out << grade << "." << endl;
				csgVec.push_back(grade);
			}
			else if ("cdh(" == line.substr(0, 4))
			{
				courseName = line.substr(4, line.find(',') - 4);
				line = line.substr(line.find(',') + 1);
				day = line.substr(0, line.find(','));
				line = line.substr(line.find(',') + 1);
				time = line.substr(0, line.find(')'));
				cdh courseTime = cdh(courseName, day, time);
				out << "cdh(" << courseTime << ")" << "." << endl;
				cdhVec.push_back(courseTime);
			}
			else
			{
				string except = "**Error";
				out << except << ": " << line << endl;
				throw except;
			}
		}
		catch (...)
		{

		}

	}
	out << "Vectors: " << endl;
	for (unsigned int i = 0; i < snapVec.size(); ++i)
	{
		out << "snap(" << snapVec.at(i) << ")" << endl;
	}
	for (unsigned int i = 0; i < csgVec.size(); ++i)
	{
		out << csgVec.at(i) << endl;
	}
	for (unsigned int i = 0; i < cdhVec.size(); ++i)
	{
		out << "cdh(" << cdhVec.at(i) << ")" << endl;
	}
	for (unsigned int i = 0; i < crVec.size(); ++i)
	{
		out << crVec.at(i) << endl;
	}

	out << endl << "Course Grades:" << endl;
	string currCourse = csgVec.at(0).getCourse();
	for (unsigned int i = 0; i < csgVec.size(); ++i)
	{
		if (currCourse != csgVec.at(i).getCourse())
		{
			out << endl;
		}
		out << csgVec.at(i).getCourse() << ",";
		for (unsigned int j = 0; j < snapVec.size(); ++j)
		{
			if (csgVec.at(i).getId() == snapVec.at(j).getStudentId())
			{
				csgVec.at(i).setId(snapVec.at(j).getName());
				out << csgVec.at(i).getId() << ",";
			}
			continue;
		}
		out << csgVec.at(i).getGrade() << endl;
	    currCourse = csgVec.at(i).getCourse();
	}

	vector<cdh> compressedCdh;
	string currDay = cdhVec.at(0).getDay();
	string currStudent = snapVec.at(0).getName();
	string currCourseCdh = cdhVec.at(0).getCourseName();
	for (unsigned int j = 0; j < cdhVec.size(); ++j)
	{
		if (currCourseCdh == cdhVec.at(j).getCourseName() && currDay != cdhVec.at(j).getDay())
		{
			currDay += cdhVec.at(j).getDay();
			cdhVec.at(j).setDay(currDay);
		}
		else if (currCourseCdh != cdhVec.at(j).getCourseName())
		{
			compressedCdh.push_back(cdhVec.at(j - 1));
		}
		currCourseCdh = cdhVec.at(j).getCourseName();
		currDay = cdhVec.at(j).getDay();
		if (currCourseCdh == cdhVec.at(j).getCourseName() && j == (cdhVec.size() - 1))
		{
			compressedCdh.push_back(cdhVec.at(j));
		}
	}

	vector<StudentClass> studentClasses;
	for (unsigned int i = 0; i < csgVec.size(); ++i)
	{
		for (unsigned int j = 0; j < snapVec.size(); ++j)
		{
			if (csgVec.at(i).getId() == snapVec.at(j).getName())
			{
				StudentClass classes = StudentClass(csgVec.at(i).getCourse(), snapVec.at(j).getName());
				studentClasses.push_back(classes);
			}
		}
	}

	SchoolSchedule schedule = SchoolSchedule(snapVec, compressedCdh, crVec, csgVec, studentClasses);

	out << endl << "Student Schedules:" << endl << schedule << endl;

	return 0;
	if (&out != &std::cout) delete(&out);
}